#!/usr/bin/python
#coding:utf-8
from fake_useragent import UserAgent
import requests,time
import cookielib
import re
import os
import sys

jenkins_task_list = ["http://Jenkins_MQ:114a2f638e0358fe63062e5c7d3abf718d@localhost:8085/job/Monkey%20Test01/build?token=qwertyuiop0123456","http://Jenkins_MQ:114a2f638e0358fe63062e5c7d3abf718d@localhost:8085/job/Monkey%20Test02/build?token=asdfghjkl0123456","http://Jenkins_MQ:114a2f638e0358fe63062e5c7d3abf718d@localhost:8085/job/Monkey%20Test03/build?token=zxcvbnm0123456"]

defaultencoding = 'utf-8'
if sys.getdefaultencoding() != defaultencoding:
    reload(sys)
    sys.setdefaultencoding(defaultencoding)

session = requests.session()
session.cookies = cookielib.LWPCookieJar(filename = "Cookies.txt")
userAgent = UserAgent().ie
print(userAgent)
header = {
    "Referer": "http://launcher.ci.3g.net.cn/login",
    'User-Agent': userAgent,
}

def task_get(Task_Path):
    f = open(Task_Path,'r')
    List = f.readlines()
    f.close()
    print(List)
    return List

def DevicesGet():
    devices = []
    os.system("adb devices >> ./devices.txt")
    f = open("./devices.txt",'r')
    n = len(f.readlines())
    #print(f.readlines())
    f.close()
    g = open("./devices.txt",'r')
    for i in range(0,n):
        s = g.readline()
        if "List of devices attached" in s:
            continue
        elif s == '':
            continue
        elif s == '\n':
            continue
        else:
            devices.append(s.split('\t')[0])
    print("Devices list:",devices)
    g.close()
    os.system("rm ./devices.txt")
    return devices

def check_Work(List):
    device_list = DevicesGet()
    #device_list = ["1","2","3"]
    num = 0
    n = 0
    m = 0
    if len(List)<=len(device_list):
        m = 0
    elif len(List)>len(device_list) != 0:
        m = len(List)/len(device_list)
    else:
        print("devices list is null!!")
    for i in range(0,len(List)+m):
        if len(device_list)>=len(List):
            name = "jenkins_"+str(i)+".txt"
	    apk_name = List[i].split("\n")[0]+"_apkInfo.txt"
	    re_apk_name = str(i)+"_apkInfo.txt"
	    os.system("mv '%s' %s" %(apk_name,re_apk_name))
            f = open(name,'w+')
            f.write(List[i])
            f.close()
            content = requests.get(jenkins_task_list[i])
            time.sleep(20)
        elif len(List)>len(device_list) != 0:
            if num<len(device_list):
                name = "jenkins_"+str(num)+".txt"
		apk_name = List[n].split("\n")[0]+"_apkInfo.txt"
	    	re_apk_name = str(num)+"_apkInfo.txt"
	    	os.system("mv '%s' %s" %(apk_name,re_apk_name))
                f = open(name,'w+')
                f.write(List[n])
                f.close()
                content = requests.get(jenkins_task_list[num])
                print(content.status_code)
                time.sleep(20)
                num += 1
                n += 1
            else:
                print("full task,into sleep...")
                time.sleep(120)
                num = 0
        else:
            print("not found device!!")



if __name__ == "__main__":
    username = "raomingqiang"
    password = "Hello123"
    Task_Path = "./task_list.txt"
    List = task_get(Task_Path)
    check_Work(List)
#    jenkinsUrl = "http://launcher.ci.3g.net.cn/job/build_gomusic_1.0/"
#    #jenkinsUrl = "http://pbasjks06.rmz.gomo.com:8080/job/Predictor/"
#    getApkInfo(jenkinsUrl,username,password)
#downloadApk(username,password)

