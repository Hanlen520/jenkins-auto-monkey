#!/usr/bin/python
#coding:utf-8

import math
import random
import os
import sys


BL = "True"
apkName=""
pkN=""


defaultencoding = 'utf-8'
if sys.getdefaultencoding() != defaultencoding:
    reload(sys)
    sys.setdefaultencoding(defaultencoding)

def DevicesGet():
    devices = []
    os.system("adb devices >> ./devices.txt")
    f = open("./devices.txt",'r')
    n = len(f.readlines())
    #print(f.readlines())
    f.close()
    g = open("./devices.txt",'r')
    for i in range(0,n):
        s = g.readline()
        if "List of devices attached" in s:
            continue
        elif s == '':
            continue
        elif s == '\n':
            continue
        else:
            devices.append(s.split('\t')[0])
    print("Devices list:",devices)
    g.close()
    os.system("rm ./devices.txt")
    return devices

def get_Info(dir1,dir2):
    g = open(dir2,'r')
    apkName = g.read().split("\n")[0]	#gets the string hand "\n",must remove!
    g.close()
    f = open(dir1+"all_task_list.txt",'r')
    info = f.readlines()
    f.close()
    for line in info:
	if apkName in line:
	    return line

def monkey_Device():
    global BL
    dv = DevicesGet()
    if dv != []:
        n = []
        for i in range(0,len(dv)):
            while True:
                num = int(math.floor(random.random()*len(dv)))
                if num not in n:
                    n.append(num)
                    break
                else:
                    continue
            str = os.popen("adb -s %s shell ps|grep com.android.commands.monkey" %dv[num]).read()
            if str == '':
                print("Selected device:",dv[num])
                return dv[num]
                break
            else:
                if i == len(dv)-1:
                    BL = "False"
                print("%s existed monkey Thread !!" %dv[num])
                continue
    else:
        BL = "False"
        print("Devices list is empty!")

def device_Info(device):
    global BL
    if BL == "True":
        Info = []
        #print("中文测试"+os.popen("adb -s %s shell getprop ro.build.version.release" %device).read())
        Info.append(os.popen("adb -s %s shell getprop ro.build.version.release" %device).read()) #版本
        Info.append(os.popen("adb -s %s shell getprop ro.product.brand" %device).read()) #品牌
        Info.append(os.popen("adb -s %s shell getprop ro.product.name" %device).read()) #设备名
        Info.append(os.popen("adb -s %s shell getprop ro.product.board" %device).read()) #处理器
        Info.append(os.popen("adb -s %s shell getprop ro.product.model" %device).read()) #型号
        Info.append(os.popen("adb -s %s shell dumpsys battery|grep level" %device).read().split(': ')[1])    #电量
        Info.append(os.popen("adb -s %s shell wm size" %device).read().split(': ')[1].split('\n')[0]+'\n')  #分别率
	try:
            Info.append(os.popen("adb -s %s shell dumpsys meminfo|grep 'Total RAM:'" %device).read().split(': ')[1].split(' (')[0]+'\n')    #总内存
            Info.append(os.popen("adb -s %s shell dumpsys meminfo|grep 'Free RAM'" %device).read().split(': ')[1].split(' (')[0]+'\n') #剩余内存
	except Exception,e:
	    print("get RAM fail,Ignore!!")
        print(Info)
        name = ["版本：","品牌：","设备名：","处理器：","型号：","电量：","分别率：","总内存：","剩余内存："]
        f = open('./DeviceInfo.txt','w+')
        for i in range(0,len(Info)):
            f.write(name[i]+Info[i])
        f.close()
    else:
        print("Not need,give up device_Info!! ")
def package_Info(dir1,dir2):
    global pkN
    global apkName
    Info = []
    #files = os.listdir(dir)
    g = open(dir2,'r')
    apkName = g.read().split("\n")[0]	#gets the string hand "\n",must remove!
    g.close()
    print("APK:%s" %apkName)
    path = dir1+apkName+".apk"
    #path = "/home/raomingqiang/文档/monkey_task/test_shell/iArtCamera.apk"
    Info.append(os.popen("aapt dump badging '%s'|grep 'application-label-en:'" %path).read().split(':')[1].split('\n')[0])   #应用名
    Info.append(os.popen("aapt dump badging '%s'|grep 'package: name='" %path).read().split("'")[1])   #包名
    Info.append(os.popen("aapt dump badging '%s'|grep 'package: name='" %path).read().split("'")[3])  #版本号
    Info.append(os.popen("aapt dump badging '%s'|grep 'package: name='" %path).read().split("'")[5])  #版本名
    print(Info)
    pkN = Info[1]
    r = open("./ApkName.txt",'w+')
    r.write(Info[0])
    r.close()
    name = ["应用名: ","包名: ","版本号: ","版本名: "]
    f = open('./ApkInfo.txt','w+')
    for i in range(0,4):
        f.write(name[i]+Info[i]+'\n')
    f.close()

def install_APK(dir1,device):
    global BL
    if BL == "True":
        try:
            os.system("adb uninstall %s" %pkN)
            print("installing APK !!")
            os.system("adb -s %s install -r '%s'" %(device,(dir1+apkName+".apk")))
        except Exception, e:
            print("install fail !!")
            BL = "False"
    else:
        print("Not need,give up install! ")

def monkey_Start(device,path):
    global BL
    os.system("rm monkey_log.txt")
    os.system("adb -s %s shell rm -r %s" %(device,path))
    if BL == "False":
        print("Not need, give up monkey!!")
    else:
        print("monkey device:%s" %device)
        print("monkey Start...")
        try:
            os.system("adb -s %s shell monkey -p %s --ignore-crashes --ignore-timeouts --monitor-native-crashes -v -v -v 5000 >> monkey_log.txt" %(device,pkN))
        except Exception, e:
            print("monkey fail !!")
            BL = "False"

def monkey_Info():
    global BL
    stats = ""
    Info = []
    if BL == "False":
        print("Not need, give up monkey_Info!!")
    else:
        f = open("./monkey_log.txt","r")
        for line in f.readlines():
            if "Network stats:" in line:
                stats = line
                break
            else:
                continue
        f.close()
        name = ["总运行时间：","数据流量：","无线网：","无网络连接："]
        Info.append(stats.split('time=')[1].split(' (')[0])
        Info.append(stats.split(' (')[1].split(' mobile')[0])
        Info.append(stats.split('mobile, ')[1].split(' wifi')[0])
        Info.append(stats.split('wifi, ')[1].split(' not connected')[0])
        print(Info)
        g = open('./MonkeyInfo.txt','w+')
        for i in range(0,4):
            g.write(name[i]+Info[i]+'\n')
        g.close()
def crash_anr_get(device,path,crashN):
    global BL
    if BL == "False":
        print("No new crash and anr!!")
    else:
        erro = 0
        os.system("mkdir anr anr2 %s" %crashN)
        #os.system("mkdir anr&&mkdir anr2&&mkdir %s" %crashN)
        os.system("rm -r anr2/* %s/*" %crashN)
        files = os.listdir("./anr")
        os.system("adb -s %s pull /data/anr ./" %device)
        os.system("adb -s %s pull %s ./" %(device,path))
        os.system("adb -s %s shell rm -r %s" %(device,path))
        dir1 = "./anr"
        dir2 = crashN
        files1 = os.listdir(dir1)
        files2 = os.listdir(dir2)
        #f.write("ANR: "+str(len(files1)-len(files))+'\n')
        for i in range(0,len(files1)):
            if files1[i] not in files:
                os.system("cp ./anr/%s ./anr2" %files1[i])
            else:
                continue
        f = open("./MonkeyInfo.txt","a+")
        f.write("ANR: "+str(len(os.listdir("./anr2")))+'\n')
        f.write("CRASH："+str(len(files2))+'\n')
        erro = len(os.listdir("./anr2"))+len(files2)
        g = open("./error.txt","w+")
        g.write(str(erro))
        g.close()
        f.close()
def send_Email(usr):
    global BL
    usr = usr
    dev = "raomingqiang@gomo.com"
    if BL == "False":
        f = open("Email.txt","w+")
        f.write(dev)
        f.close()
    else:
        f = open("Email.txt","w+")
        f.write(usr)
        f.close()


def AutoTestStart():
    device = monkey_Device()
    dir1 = "/home/raomingqiang/文档/monkey_task/test_shell/"
    dir2 = "/home/raomingqiang/文档/monkey_task/test_shell/jenkins_0.txt"
    line = get_Info(dir1,dir2)
    crashN = line.split("||")[2]
    path = line.split("||")[3]
    usr = line.split("||")[4]
    package_Info(dir1,dir2)
    device_Info(device)
    install_APK(dir1,device)
    monkey_Start(device,path)
    monkey_Info()
    crash_anr_get(device,path,crashN)
    send_Email(usr)


if __name__ == "__main__":
    AutoTestStart()

