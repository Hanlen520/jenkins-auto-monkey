#!/usr/bin/python
#coding:utf-8
from fake_useragent import UserAgent
import requests,time
import cookielib
import re
import os
import sys


ProjectName=""
APKLink=""
LastBuildNum=""
BL="True"
task_list=[]



defaultencoding = 'utf-8'
if sys.getdefaultencoding() != defaultencoding:
    reload(sys)
    sys.setdefaultencoding(defaultencoding)

log = None

class Log(object):
    __logfile = None
    def __init__(self, filePath, fileName):
        self.__logfile = open(filePath + os.sep + fileName, 'a+')
    def addLog(content):
        timeStr=time.ctime(time.time())
        self.__logfile.write(timeStr+"     "+content.encode('utf-8'))
        self.__logfile.write(os.linesep + '#############################' + os.linesep)
        self.__logfile.flush()
    def closeFile(self):
        self.__logfile.close()
    def setHeader(self, content):
        self.__logfile.write(content.encode('utf-8'))
        self.__logfile.write(os.linesep)
        self.__logfile.flush()
    
#print(f"user cookielib in python2.x")

session = requests.session()
session.cookies = cookielib.LWPCookieJar(filename = "Cookies.txt")
userAgent = UserAgent().ie
print(userAgent)
header = {
    "Referer": "http://launcher.ci.3g.net.cn/login",
    'User-Agent': userAgent,
}

def getTaskList(Task_Path):
    f = open(Task_Path,'r')
    List = f.readlines()
    #print(list)
    f.close()
    return List

def gatJenkinsCrumb(jenkinsUrl,username,password):
    global BL
    crumbData = None
    try:
        crumbUrlPath = 'crumbIssuer/api/xml?xpath=concat(//crumbRequestField,":",//crumb)'
        pattern = re.compile(r'^(http://)[\w.:]+(/)')
        jenkinsHostUrl = pattern.match(jenkinsUrl).group()
        jenkinsCrumbUrl = jenkinsHostUrl + crumbUrlPath
        r_crumb = requests.get(jenkinsCrumbUrl, auth=(username, password))
        print 'r_crumb.content:%s url:%s'%(r_crumb.content, jenkinsCrumbUrl)
        crumbInfo = r_crumb.content.split(':')
        crumbKey = crumbInfo[0]
        crumbValue = crumbInfo[1]
        crumbData = {}
        crumbData[crumbKey] = crumbValue
        print crumbData
    except Exception, e:
        #logContent = 'get crumb :' + e.message
        #logContent = logContent + os.linesep + 'jenkinsUrl' + jenkinsUrl
        #lg = Log()
        #lg.addLog(logContent)
        print("Error",e)
        BL = "False"
    return crumbData

def loginGetPage(jenkinsUrl,username,password):
    global LastBuildNum,BL
    content = ""
    if BL == "True":
        try:
            print("Start login...")
            crumbData = gatJenkinsCrumb(jenkinsUrl=jenkinsUrl,username=username,password=password)
            responseRes = requests.post(jenkinsUrl,auth=(username,password),data=crumbData,headers=header)
            print(responseRes.status_code)
            #print(responseRes.text)
            content = responseRes.content
            #print("PageContent:",content)
            f = open('./HomePageContent.txt','w+')
            f.write(content)
#           f.seek(0,0) #reset point
#           while True:
#               if "Last build" in f.readline():
#                   print(f.readline())
#                   break
            f.close()
            str = content
            ls = str.split('Last build(#')
            LastBuildNum = ls[1].split('),')[0]
            print("Last Build:#%s" %(LastBuildNum))
            consolePageUrl = jenkinsUrl+LastBuildNum+'/console'
            print("consolePageUrl:%s" %(consolePageUrl))
            responseRes2 = requests.post(consolePageUrl,auth=(username,password),data=crumbData,headers=header)
            content2 = responseRes2.content
            e = open('./ApkPageContent.txt','w+')
            e.write(content2)
            e.close()
        except Exception, e:
            #logContent = 'other : ' + repr(e.message)
            #logContent = logContent + os.linesep + 'jenkinsUrl : ' + jenkinsUrl
            #lg = Log()
            #lg.addLog(logContent)
            print("Error:",e)
            BL = "False"
            LastBuildNum = ""
    else:
        print("get crumbData fail!!")
        LastBuildNum = ""
    #return content

def getApkInfo(name):
    global APKLink,BL
    if BL == "True":
        try:
            path = name+"_apkInfo.txt"
            f = open('./ApkPageContent.txt','r')
            g = open(path,'w+')
            temp=["Sending email to:","Finished:","apk size :"]
            for line in f.readlines():
                if "http://" in line and ".apk" in line:
                    print("line:",line)
                    APKLink = line.split("'")[1]
                    print(APKLink)
                    g.write("APK Link:")
                    g.write(APKLink+'\n\n')
                for i in range(0,len(temp)):
                    if temp[i] in line :
                        g.write(line+'\n')
            f.close()
            g.close()
        except Exception,e:
            print("Error:",e)
            BL = "False"
    else:
        print("something error!!")

def downloadApk(name,username,password):
    global BL
    if BL == "True":
        try:
            global APKLink
            apkName = name.split('||')[0]+".apk"
            print("APKDownloadLink:%s" %APKLink)
            file = requests.get(APKLink,auth=(username,password))
            apk = open(apkName,'wb+')
            apk.write(file.content)
            apk.close()
            print("Download APK Success")
        except Exception,e:
            print("Download fail!Error:",e)
            BL = "False"
    else:
        print("something error,give up download!!")

def getTaskNeed(List,username,password):
    global LastBuildNum,BL
    username = username
    password = password
    for i in range(0,len(List)):
        name = List[i].split('||')[0]
        print("checking %s" %name)
        path = name+"_buildNum.txt"
        os.system("touch './%s'" %path)
        g = open(path,'r')
        BuildNum = g.read()
        g.close()
        jenkinsUrl = List[i].split('||')[1]
        loginGetPage(jenkinsUrl,username,password)
        if LastBuildNum != "" and LastBuildNum != BuildNum:
            f = open(path,'w+')
            f.write(LastBuildNum)
            f.close()
            getApkInfo(name)
            downloadApk(name,username,password)
            task_list.append(name)
        else:
            print("No new version or something error,give up download!")
        BL = "True"
    print(task_list)
    j = open("./task_list.txt",'w+')
    for n in task_list:
    	j.write(n+'\n')
    j.close()

if __name__ == "__main__":
    username = "raomingqiang"
    password = "Hello123"
    Task_Path = "./all_task_list.txt"
    List = getTaskList(Task_Path)
    getTaskNeed(List,username,password)
#    jenkinsUrl = "http://launcher.ci.3g.net.cn/job/build_gomusic_1.0/"
#    #jenkinsUrl = "http://pbasjks06.rmz.gomo.com:8080/job/Predictor/"
#    getApkInfo(jenkinsUrl,username,password)
#downloadApk(username,password)

